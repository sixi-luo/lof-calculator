# LOF基金折溢价计算器 PWA

实时计算LOF基金折溢价的Web应用，支持PWA安装到手机主屏幕。

## 快速部署

### 1. 上传到GitHub
将所有文件上传到你的GitHub仓库根目录。

### 2. 部署到Vercel
1. 打开 https://vercel.com
2. 用GitHub登录
3. 点击 "Add New..." → "Project"
4. 选择你的仓库
5. 点击 "Deploy"

### 3. 手机安装
1. 手机Chrome打开Vercel网址
2. 点击菜单 → "添加到主屏幕"

## 功能
- 实时获取LOF基金净值和行情
- 估算净值和折溢价计算
- 近30天历史数据
- 支持非LOF证券代码
- PWA支持

## 技术栈
- Next.js 16 + React 19
- TypeScript
- Tailwind CSS 4
- 东方财富API

---
免责声明：数据仅供参考，不构成投资建议。

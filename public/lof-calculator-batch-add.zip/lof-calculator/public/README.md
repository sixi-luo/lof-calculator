LOF Calculator

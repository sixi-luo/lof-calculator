import { NextRequest, NextResponse } from 'next/server'
import { serverCache } from '@/utils/server-cache'

// ============================================================
// TickFlow API 配置
// ============================================================
const TICKFLOW_API_KEY = 'tk_30ae030be65b43ee895ad79b00b75acd'
const TICKFLOW_BASE_URL = 'https://api.tickflow.org/v1'

// ============================================================
// 类型定义
// ============================================================
interface IndexConfig {
  index_code: string
  index_name: string
  coefficient: number
  is_manual?: boolean
  manual_change_percent?: number
}

interface LOFConfig {
  indices: IndexConfig[]
}

interface NavHistoryItem {
  date: string
  nav: number | null
  accumulated_nav: number | null
}

interface StockQuote {
  code: string
  name: string
  price: number | null
  change_percent: number | null
  change: number | null
}

interface KlineItem {
  date: string
  open: number | null
  close: number | null
  high: number | null
  low: number | null
  change_percent: number | null
}

interface IndexData {
  index_code: string
  index_name: string
  coefficient: number
  change_percent: number | null
  source: string
  is_manual?: boolean
}

// ============================================================
// TickFlow API 数据源
// ============================================================
const TICKFLOW_HEADERS: Record<string, string> = {
  'X-API-Key': TICKFLOW_API_KEY,
  'Content-Type': 'application/json',
}

// 交易所映射：根据代码判断交易所
function getExchange(code: string): string {
  // 上证：6开头、9开头、000开头指数
  if (code.startsWith('6') || code.startsWith('9') || code.startsWith('000') || code.startsWith('880')) {
    return 'SH'
  }
  // 深证：0开头、3开头、16开头、5开头
  return 'SZ'
}

// 格式化代码为TickFlow格式
function formatSymbol(code: string): string {
  const exchange = getExchange(code)
  return `${code}.${exchange}`
}

// TickFlow API 请求
async function tickflowFetch(endpoint: string, params: Record<string, string>): Promise<unknown> {
  const url = new URL(`${TICKFLOW_BASE_URL}${endpoint}`)
  Object.entries(params).forEach(([key, value]) => {
    if (value) url.searchParams.set(key, value)
  })

  try {
    const response = await fetch(url.toString(), {
      headers: TICKFLOW_HEADERS,
      signal: AbortSignal.timeout(15000),
    })

    if (!response.ok) {
      console.error(`TickFlow API错误: ${response.status}`)
      return null
    }

    return await response.json()
  } catch (error) {
    console.error('TickFlow API请求失败:', error)
    return null
  }
}

// 通过TickFlow获取实时行情
async function getTickflowQuote(code: string): Promise<{ data: StockQuote | null, source: string }> {
  return serverCache.getOrFetch(
    'quote',
    async () => {
      const symbol = formatSymbol(code)
      const result = await tickflowFetch('/quotes', { symbols: symbol }) as {
        data?: Array<{
          symbol: string
          last_price: number
          prev_close: number
          open: number
          high: number
          low: number
          volume: number
          amount: number
          timestamp: number
          ext?: {
            name: string
            change_pct: number
            change_amount: number
          }
        }>
      }

      if (result?.data?.[0]) {
        const d = result.data[0]
        return {
          data: {
            code: code,
            name: d.ext?.name || '',
            price: d.last_price,
            change_percent: d.ext?.change_pct ? d.ext.change_pct * 100 : null,
            change: d.ext?.change_amount || null,
          },
          source: 'TickFlow'
        }
      }

      return { data: null, source: 'TickFlow' }
    },
    { forceRefresh: false, keyParts: [code] }
  )
}

// 通过TickFlow获取K线数据
async function getTickflowKline(code: string, count: number = 30): Promise<{ data: KlineItem[], source: string }> {
  return serverCache.getOrFetch(
    'kline',
    async () => {
      const symbol = formatSymbol(code)
      const result = await tickflowFetch('/klines', {
        symbol: symbol,
        interval: '1d',
        limit: String(count)
      }) as {
        data?: {
          timestamp: number[]
          open: number[]
          high: number[]
          low: number[]
          close: number[]
          volume: number[]
        }
      }

      if (result?.data?.timestamp?.length) {
        const d = result.data
        const klines: KlineItem[] = []
        
        for (let i = 0; i < d.timestamp.length; i++) {
          const date = new Date(d.timestamp[i]).toISOString().split('T')[0]
          const prevClose = i > 0 ? d.close[i - 1] : null
          const changePercent = prevClose && d.close[i] 
            ? ((d.close[i] - prevClose) / prevClose) * 100 
            : null

          klines.push({
            date,
            open: d.open[i] || null,
            close: d.close[i] || null,
            high: d.high[i] || null,
            low: d.low[i] || null,
            change_percent: changePercent,
          })
        }

        return { data: klines, source: 'TickFlow' }
      }

      return { data: [], source: 'TickFlow' }
    },
    { forceRefresh: false, keyParts: [code, String(count)] }
  )
}

// ============================================================
// 东方财富API（备用，用于LOF净值数据）
// ============================================================
const EM_HEADERS: Record<string, string> = {
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
  'Accept': '*/*',
  'Referer': 'https://quote.eastmoney.com/',
}

async function emFetch(url: string): Promise<string | null> {
  try {
    const response = await fetch(url, {
      headers: EM_HEADERS,
      signal: AbortSignal.timeout(15000),
    })
    if (!response.ok) return null
    return await response.text()
  } catch {
    return null
  }
}

// 获取LOF净值历史（东方财富）
async function getEMFundNavHistory(fundCode: string, count: number = 30): Promise<{ data: NavHistoryItem[], source: string }> {
  return serverCache.getOrFetch(
    'nav',
    async () => {
      const url = `https://fund.eastmoney.com/f10/F10DataApi.aspx?type=lsjz&code=${fundCode}&page=1&sdate=&edate=&per=${count}`
      const html = await emFetch(url)

      if (!html) {
        return { data: [], source: '东财API' }
      }

      const pattern = /<td>(\d{4}-\d{2}-\d{2})<\/td>\s*<td[^>]*>([\d.]+)<\/td>\s*<td[^>]*>([\d.]+)<\/td>/g
      const result: NavHistoryItem[] = []
      let match

      while ((match = pattern.exec(html)) !== null) {
        result.push({
          date: match[1],
          nav: parseFloat(match[2]) || null,
          accumulated_nav: parseFloat(match[3]) || null,
        })
      }

      return { data: result, source: '东财API' }
    },
    { forceRefresh: false, keyParts: [fundCode, String(count)] }
  )
}

// ============================================================
// LOF配置
// ============================================================
const DEFAULT_LOF_CONFIG: Record<string, LOFConfig> = {
  '161725': { indices: [{ index_code: '399997', index_name: '中证白酒', coefficient: 0.95 }] },
  '161118': { indices: [{ index_code: '000932', index_name: '中证主要消费', coefficient: 0.95 }] },
  '161035': { indices: [{ index_code: '399989', index_name: '中证医疗', coefficient: 0.95 }] },
  '161122': { indices: [{ index_code: '399989', index_name: '中证医疗', coefficient: 0.95 }] },
  '161028': { indices: [{ index_code: '399808', index_name: '中证新能源', coefficient: 0.95 }] },
  '161024': { indices: [{ index_code: '399967', index_name: '中证军工', coefficient: 0.95 }] },
  '161720': { indices: [{ index_code: '399975', index_name: '中证全指证券公司', coefficient: 0.95 }] },
  '161723': { indices: [{ index_code: '399986', index_name: '中证银行', coefficient: 0.95 }] },
  '161038': { indices: [{ index_code: '000827', index_name: '中证环保', coefficient: 0.95 }] },
  '161726': { indices: [{ index_code: '000022', index_name: '中证基建', coefficient: 0.95 }] },
  '160620': { indices: [{ index_code: '000979', index_name: '有色金属', coefficient: 0.95 }] },
  '161632': { indices: [{ index_code: '399994', index_name: '信息安全', coefficient: 0.95 }] },
  '161729': { indices: [{ index_code: '399971', index_name: '中证传媒', coefficient: 0.95 }] },
  '161116': { indices: [{ index_code: 'AU9999', index_name: '黄金现货', coefficient: 0.99 }] },
  '161811': { indices: [{ index_code: '000300', index_name: '沪深300', coefficient: 0.95 }] },
  '161717': { indices: [{ index_code: '000905', index_name: '中证500', coefficient: 0.95 }] },
  '161913': { indices: [{ index_code: '399006', index_name: '创业板指', coefficient: 0.95 }] },
  '161831': { indices: [{ index_code: 'HSI', index_name: '恒生指数', coefficient: 0.95 }] },
  '161130': { indices: [{ index_code: 'NDX', index_name: '纳斯达克100', coefficient: 0.95 }] },
}

function getLOFConfig(fundCode: string, customConfig: Record<string, LOFConfig> | null): LOFConfig {
  if (customConfig && customConfig[fundCode]) {
    return customConfig[fundCode]
  }
  return DEFAULT_LOF_CONFIG[fundCode] || { indices: [{ index_code: '', index_name: '未知', coefficient: 0.95 }] }
}

function isLOFCode(code: string): boolean {
  return code.startsWith('16') || code.startsWith('50')
}

function getYesterdayNav(navHistory: NavHistoryItem[]): {
  prevNav: number | null
  prevNavDate: string | null
  todayNav: number | null
  todayNavDate: string | null
  navUpdatedToday: boolean
} {
  if (!navHistory || navHistory.length === 0) {
    return { prevNav: null, prevNavDate: null, todayNav: null, todayNavDate: null, navUpdatedToday: false }
  }

  const today = new Date().toISOString().split('T')[0]
  const latest = navHistory[0]

  if (latest.date === today) {
    const todayNav = latest.nav
    const todayNavDate = latest.date
    if (navHistory.length > 1) {
      const prev = navHistory[1]
      return { prevNav: prev.nav, prevNavDate: prev.date, todayNav, todayNavDate, navUpdatedToday: true }
    }
    return { prevNav: null, prevNavDate: null, todayNav, todayNavDate, navUpdatedToday: true }
  }

  return { prevNav: latest.nav, prevNavDate: latest.date, todayNav: null, todayNavDate: null, navUpdatedToday: false }
}

// ============================================================
// API处理函数
// ============================================================
async function getSingleData(code: string, customConfig: Record<string, LOFConfig> | null, forceRefresh: boolean = false) {
  if (!code) {
    return { code: '', error: '请提供代码' }
  }

  const isLOF = isLOFCode(code)

  try {
    // 非LOF代码：直接获取股票行情（TickFlow）
    if (!isLOF) {
      const { data: quote, source } = await getTickflowQuote(code)

      if (!quote || !quote.name) {
        return {
          code,
          error: '无法获取该代码的行情数据',
        }
      }

      return {
        code,
        name: quote.name,
        price: quote.price,
        change_percent: quote.change_percent,
        change: quote.change,
        prev_nav: null,
        prev_nav_date: null,
        today_nav: null,
        today_nav_date: null,
        nav_updated_today: false,
        indices: [],
        total_index_change: null,
        estimated_nav: null,
        premium: null,
        estimation_error: null,
        data_sources: { quote: source, nav: 'none' },
        is_lof: false,
      }
    }

    // LOF代码：获取净值和计算折溢价
    const config = getLOFConfig(code, customConfig)
    const indices = config.indices

    // 获取LOF行情（TickFlow）
    const { data: quote, source: quoteSource } = await getTickflowQuote(code)

    if (!quote || !quote.name) {
      return {
        code,
        error: '无法获取该代码的数据',
      }
    }

    const fundName = quote.name

    // 获取净值历史（东方财富，因为TickFlow不支持LOF净值）
    const { data: navHistory, source: navSource } = await getEMFundNavHistory(code, 10)

    const { prevNav, prevNavDate, todayNav, todayNavDate, navUpdatedToday } = getYesterdayNav(navHistory)

    // 获取所有追踪指数的行情（TickFlow）
    const indicesData: IndexData[] = []
    for (const idx of indices) {
      const indexCode = idx.index_code
      const coefficient = idx.coefficient || 0.95
      const manualChange = idx.manual_change_percent
      const isManual = idx.is_manual || false

      if (isManual && manualChange !== undefined) {
        indicesData.push({
          index_code: indexCode || 'MANUAL',
          index_name: idx.index_name || '手动输入',
          coefficient,
          change_percent: manualChange,
          source: 'manual',
          is_manual: true,
        })
      } else if (indexCode && /^\d/.test(indexCode)) {
        const { data: indexQuote } = await getTickflowQuote(indexCode)
        indicesData.push({
          index_code: indexCode,
          index_name: idx.index_name || '',
          coefficient,
          change_percent: indexQuote?.change_percent ?? null,
          source: 'TickFlow',
          is_manual: false,
        })
      } else {
        indicesData.push({
          index_code: indexCode,
          index_name: idx.index_name || '',
          coefficient,
          change_percent: null,
          source: 'invalid',
          is_manual: false,
        })
      }
    }

    // 计算估算净值
    let estimatedNav: number | null = null
    let totalChange = 0
    if (prevNav) {
      const validIndices = indicesData.filter(i => i.change_percent !== null)
      if (validIndices.length > 0) {
        for (const idx of validIndices) {
          totalChange += idx.change_percent! * idx.coefficient
        }
        estimatedNav = prevNav * (1 + totalChange / 100)
      }
    }

    // 计算估算溢价
    let premium: number | null = null
    if (quote.price && estimatedNav && estimatedNav > 0) {
      premium = (quote.price - estimatedNav) / estimatedNav * 100
    }

    // 计算估值误差
    let estimationError: number | null = null
    if (navUpdatedToday && todayNav && estimatedNav) {
      estimationError = (todayNav - estimatedNav) / estimatedNav * 100
    }

    return {
      code,
      name: fundName,
      price: quote.price,
      change_percent: quote.change_percent,
      change: quote.change,
      prev_nav: prevNav,
      prev_nav_date: prevNavDate,
      today_nav: todayNav,
      today_nav_date: todayNavDate,
      nav_updated_today: navUpdatedToday,
      indices: indicesData,
      total_index_change: totalChange || null,
      estimated_nav: estimatedNav ? Math.round(estimatedNav * 10000) / 10000 : null,
      premium: premium ? Math.round(premium * 100) / 100 : null,
      estimation_error: estimationError ? Math.round(estimationError * 100) / 100 : null,
      data_sources: { quote: quoteSource, nav: navSource },
      is_lof: true,
    }
  } catch (error) {
    return { code, error: String(error) }
  }
}

async function getBatchData(codes: string[], customConfig: Record<string, LOFConfig> | null, forceRefresh: boolean = false) {
  const results = []
  for (const code of codes) {
    const data = await getSingleData(code, customConfig, forceRefresh)
    results.push(data)
  }
  return results
}

async function getHistoryData(code: string, customConfig: Record<string, LOFConfig> | null, _forceRefresh: boolean = false) {
  if (!code) {
    return { error: '请提供代码' }
  }

  try {
    const isLOF = isLOFCode(code)

    // 获取价格K线（TickFlow）
    const { data: klineData, source: klineSource } = await getTickflowKline(code, 30)

    // 非LOF代码：只返回价格K线
    if (!isLOF) {
      const history = klineData.map(item => ({
        date: item.date,
        nav: null,
        accumulated_nav: null,
        price: item.close,
        premium: null,
        index_change: null,
        estimated_nav: null,
        estimation_error: null,
      }))

      return {
        code,
        name: null,
        index_name: '',
        coefficient: 1.0,
        history,
        is_lof: false,
        data_sources: { nav: 'none', kline: klineSource },
      }
    }

    // LOF代码：获取完整数据
    const config = getLOFConfig(code, customConfig)
    const indices = config.indices
    const firstIndex = indices[0] || {}

    // 获取净值历史（东方财富）
    const { data: navHistory, source: navSource } = await getEMFundNavHistory(code, 35)

    // 获取第一个指数的K线（TickFlow）
    let indexKline: KlineItem[] = []
    const indexCode = firstIndex.index_code
    const coefficient = firstIndex.coefficient || 0.95
    const isManual = firstIndex.is_manual || false

    if (!isManual && indexCode && /^\d/.test(indexCode)) {
      const { data } = await getTickflowKline(indexCode, 35)
      indexKline = data
    }

    // 创建日期索引
    const navByDate: Record<string, NavHistoryItem> = {}
    for (const item of navHistory) {
      navByDate[item.date] = item
    }

    const priceByDate: Record<string, KlineItem> = {}
    for (const item of klineData) {
      priceByDate[item.date] = item
    }

    const indexByDate: Record<string, KlineItem> = {}
    for (const item of indexKline) {
      indexByDate[item.date] = item
    }

    // 合并历史数据
    const allDates = Object.keys(navByDate).sort().reverse()
    const history = []

    for (let i = 0; i < Math.min(allDates.length, 30); i++) {
      const date = allDates[i]
      const navItem = navByDate[date] || {}
      const priceItem = priceByDate[date] || {}
      const indexItem = indexByDate[date] || {}

      const nav = navItem.nav
      const price = priceItem.close
      const indexChange = indexItem.change_percent

      let premium: number | null = null
      if (nav && price) {
        premium = Math.round((price - nav) / nav * 10000) / 100
      }

      let estimatedNav: number | null = null
      let estimationError: number | null = null

      const prevDate = allDates[i + 1]
      if (prevDate && indexChange !== null) {
        const prevNav = navByDate[prevDate]?.nav
        if (prevNav) {
          estimatedNav = Math.round(prevNav * (1 + indexChange / 100 * coefficient) * 10000) / 10000
          if (nav && estimatedNav) {
            estimationError = Math.round((nav - estimatedNav) / estimatedNav * 10000) / 100
          }
        }
      }

      history.push({
        date,
        nav,
        accumulated_nav: navItem.accumulated_nav,
        price,
        premium,
        index_change: indexChange,
        estimated_nav: estimatedNav,
        estimation_error: estimationError,
      })
    }

    return {
      code,
      name: null,
      index_name: firstIndex.index_name || '',
      coefficient,
      history,
      is_lof: true,
      data_sources: { nav: navSource, kline: klineSource },
    }
  } catch (error) {
    return { code, error: String(error) }
  }
}

// ============================================================
// Next.js API Route Handler
// ============================================================
export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams
  const action = searchParams.get('action')
  const code = searchParams.get('code')
  const codes = searchParams.get('codes')
  const configStr = searchParams.get('config')
  const forceRefresh = searchParams.get('force') === 'true'

  let customConfig: Record<string, LOFConfig> | null = null
  if (configStr) {
    try {
      customConfig = JSON.parse(configStr)
    } catch {
      // 忽略解析错误
    }
  }

  try {
    let result

    if (action === 'batch' && codes) {
      const codeList = codes.split(',').map(c => c.trim()).filter(c => c)
      result = await getBatchData(codeList, customConfig, forceRefresh)
    } else if (action === 'single' && code) {
      result = await getSingleData(code, customConfig, forceRefresh)
    } else if (action === 'history' && code) {
      result = await getHistoryData(code, customConfig, forceRefresh)
    } else {
      result = { error: '未知操作' }
    }

    const stats = serverCache.getStats()
    const response = NextResponse.json(result)
    response.headers.set('X-Cache-Size', String(stats.size))
    response.headers.set('X-Cache-Types', JSON.stringify(stats.types))
    response.headers.set('X-Data-Source', 'TickFlow + 东财API')

    return response
  } catch (error) {
    return NextResponse.json(
      { error: '数据获取失败', detail: String(error) },
      { status: 500 }
    )
  }
}

export const dynamic = 'force-dynamic'

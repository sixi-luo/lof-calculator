'use client'

import { useState, useEffect, useCallback, Fragment } from 'react'
import { dataCache } from '@/utils/cache'

// 类型定义
interface IndexConfig {
  index_code: string
  index_name: string
  coefficient: number
}

interface LOFConfig {
  indices: IndexConfig[]
}

interface IndexData {
  index_code: string
  index_name: string
  coefficient: number
  change_percent: number | null
  source: string
}

interface LOFBatchItem {
  code: string
  name: string
  prev_nav: number | null
  prev_nav_date: string | null
  today_nav: number | null
  today_nav_date: string | null
  nav_updated_today: boolean
  price: number | null
  change_percent: number | null
  indices: IndexData[]
  total_index_change: number | null
  estimated_nav: number | null
  premium: number | null
  estimation_error: number | null
  data_sources?: {
    quote: string
    nav: string
  }
  error?: string
  _cachedAt?: number  // 缓存时间戳
}

interface HistoryItem {
  date: string
  nav: number | null
  accumulated_nav: number | null
  price: number | null
  premium: number | null
  index_change: number | null
  estimated_nav: number | null
  estimation_error: number | null
}

interface LOFHistory {
  code: string
  name: string
  index_name: string
  coefficient: number
  history: HistoryItem[]
  data_sources?: {
    nav: string
    kline: string
  }
  error?: string
  _cachedAt?: number
}

// 本地存储键名
const STORAGE_KEYS = {
  SELECTED_CODES: 'lof_selected_codes',
  CUSTOM_CONFIGS: 'lof_custom_configs',
}

// 数据来源显示名称
const SOURCE_NAMES: Record<string, string> = {
  'TickFlow': 'TickFlow',
  '东财API': '东财API',
  'http': '东财API',
  'invalid': '无效',
  'manual': '手动输入',
}

export default function Home() {
  const [selectedCodes, setSelectedCodes] = useState<string[]>([])
  const [customConfigs, setCustomConfigs] = useState<Record<string, LOFConfig>>({})
  const [batchData, setBatchData] = useState<LOFBatchItem[]>([])
  const [historyData, setHistoryData] = useState<Record<string, LOFHistory>>({})
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [expandedCode, setExpandedCode] = useState<string | null>(null)
  const [editModal, setEditModal] = useState<{ code: string; config: LOFConfig } | null>(null)
  const [cacheStats, setCacheStats] = useState<{ count: number; types: Record<string, number> }>({ count: 0, types: {} })
  const [lastUpdateTime, setLastUpdateTime] = useState<number | null>(null)
  const [forceRefresh, setForceRefresh] = useState(false)

  // 从本地存储加载数据
  useEffect(() => {
    const savedCodes = localStorage.getItem(STORAGE_KEYS.SELECTED_CODES)
    const savedConfigs = localStorage.getItem(STORAGE_KEYS.CUSTOM_CONFIGS)
    
    if (savedCodes) {
      try {
        setSelectedCodes(JSON.parse(savedCodes))
      } catch (e) {
        console.error('加载已选代码失败:', e)
      }
    }
    
    if (savedConfigs) {
      try {
        setCustomConfigs(JSON.parse(savedConfigs))
      } catch (e) {
        console.error('加载自定义配置失败:', e)
      }
    }

    // 更新缓存统计
    setCacheStats(dataCache.getStats())
  }, [])

  // 保存到本地存储
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SELECTED_CODES, JSON.stringify(selectedCodes))
  }, [selectedCodes])

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CUSTOM_CONFIGS, JSON.stringify(customConfigs))
  }, [customConfigs])

  const removeCode = (code: string) => {
    setSelectedCodes(prev => prev.filter(c => c !== code))
    setBatchData(prev => prev.filter(item => item.code !== code))
    setHistoryData(prev => {
      const newData = { ...prev }
      delete newData[code]
      return newData
    })
    // 清除该代码的缓存
    dataCache.delete('batch', code)
    dataCache.delete('history', code)
    setCacheStats(dataCache.getStats())
  }

  const addCode = (code: string) => {
    const trimmed = code.trim()
    if (trimmed && /^\d{6}$/.test(trimmed) && !selectedCodes.includes(trimmed)) {
      setSelectedCodes(prev => [...prev, trimmed])
    }
  }

  // 批量添加代码：支持换行、中英文逗号分隔
  const addCodes = (input: string) => {
    // 统一替换：中文逗号->英文逗号，换行->英文逗号
    const normalized = input
      .replace(/，/g, ',')  // 中文逗号转英文
      .replace(/\n/g, ',')   // 换行转逗号
      .replace(/；/g, ',')   // 中文分号转逗号
      .replace(/;/g, ',')    // 英文分号转逗号
    
    // 分割并处理每个代码
    const codes = normalized
      .split(',')
      .map(c => c.trim())
      .filter(c => c.length > 0)
    
    // 去重并添加有效代码
    const validCodes = codes.filter(c => /^\d{6}$/.test(c))
    const uniqueCodes = [...new Set(validCodes)].filter(c => !selectedCodes.includes(c))
    
    if (uniqueCodes.length > 0) {
      setSelectedCodes(prev => [...prev, ...uniqueCodes])
    }
    
    return {
      added: uniqueCodes.length,
      invalid: codes.filter(c => !/^\d{6}$/.test(c)).length
    }
  }

  const updateCustomConfig = (code: string, config: LOFConfig) => {
    setCustomConfigs(prev => ({
      ...prev,
      [code]: config
    }))
    setEditModal(null)
    // 清除该代码的缓存，下次请求使用新配置
    dataCache.delete('batch', code)
    dataCache.delete('history', code)
  }

  const fetchBatchData = useCallback(async (force: boolean = false) => {
    if (selectedCodes.length === 0) {
      setError('请至少添加一个LOF基金代码')
      return
    }
    
    setLoading(true)
    setError('')
    
    const now = Date.now()
    const results: LOFBatchItem[] = []
    const codesToFetch: string[] = []
    
    // 检查前端缓存（仅对批量数据，强制刷新时跳过）
    if (!force) {
      for (const code of selectedCodes) {
        const { data, isStale } = dataCache.get<LOFBatchItem>('batch', code, false)
        if (!isStale && data) {
          results.push(data)
        } else {
          codesToFetch.push(code)
        }
      }
    } else {
      codesToFetch.push(...selectedCodes)
    }

    try {
      // 请求后端API（强制刷新时传递force参数）
      if (codesToFetch.length > 0) {
        const configParam = encodeURIComponent(JSON.stringify(customConfigs))
        const forceParam = force ? '&force=true' : ''
        const response = await fetch(`/api/lof?action=batch&codes=${codesToFetch.join(',')}&config=${configParam}${forceParam}`)
        const result = await response.json()
        
        if (result.error) {
          setError(result.error)
          if (results.length === 0) {
            setBatchData([])
          }
        } else {
          // 缓存新数据（无论是否强制刷新，都缓存最新数据）
          for (const item of result) {
            if (!item.error) {
              item._cachedAt = now
              dataCache.set('batch', item.code, item)
            }
            results.push(item)
          }
        }
      }

      // 按原始顺序排序
      const sortedResults = selectedCodes
        .map(code => results.find(r => r.code === code))
        .filter((item): item is LOFBatchItem => !!item)
      
      setBatchData(sortedResults)
      setLastUpdateTime(now)
      setCacheStats(dataCache.getStats())
      
      // 获取历史数据（历史数据缓存1天，不受强制刷新影响）
      const historyResults: Record<string, LOFHistory> = { ...historyData }
      
      for (const item of sortedResults) {
        if (!item.error && item.code) {
          // 检查历史数据缓存（缓存1天）
          const { data: cachedHistory, isStale } = dataCache.get<LOFHistory>('history', item.code, false)
          
          if (!isStale && cachedHistory) {
            historyResults[item.code] = cachedHistory
          } else {
            try {
              const configParam = encodeURIComponent(JSON.stringify(customConfigs))
              const histResponse = await fetch(`/api/lof?action=history&code=${item.code}&config=${configParam}`)
              const histResult = await histResponse.json()
              histResult._cachedAt = now
              historyResults[item.code] = histResult
              
              // 缓存历史数据（1天）
              if (!histResult.error) {
                dataCache.set('history', item.code, histResult)
              }
            } catch (e) {
              console.error(`获取 ${item.code} 历史数据失败:`, e)
            }
          }
        }
      }
      
      setHistoryData(historyResults)
      setCacheStats(dataCache.getStats())
      
    } catch (err) {
      setError('数据获取失败，请确保后端服务已启动')
      if (results.length === 0) {
        setBatchData([])
      }
    } finally {
      setLoading(false)
      setForceRefresh(false)
    }
  }, [selectedCodes, customConfigs, historyData])

  const clearAllCache = () => {
    dataCache.clear()
    setBatchData([])
    setHistoryData({})
    setCacheStats(dataCache.getStats())
    setLastUpdateTime(null)
  }

  const formatNumber = (num: number | null | undefined, decimals: number = 4) => {
    if (num === null || num === undefined || isNaN(num)) return '-'
    return num.toFixed(decimals)
  }

  const formatPercent = (num: number | null | undefined, decimals: number = 2) => {
    if (num === null || num === undefined || isNaN(num)) return '-'
    const sign = num >= 0 ? '+' : ''
    return `${sign}${num.toFixed(decimals)}%`
  }

  const getSourceName = (source: string) => {
    return SOURCE_NAMES[source] || source
  }

  const formatTime = (timestamp: number | null) => {
    if (!timestamp) return '-'
    const date = new Date(timestamp)
    return date.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
  }

  const getCacheAge = (cachedAt: number | undefined) => {
    if (!cachedAt) return null
    const age = Date.now() - cachedAt
    const seconds = Math.floor(age / 1000)
    if (seconds < 60) return `${seconds}秒前`
    const minutes = Math.floor(seconds / 60)
    if (minutes < 60) return `${minutes}分钟前`
    const hours = Math.floor(minutes / 60)
    return `${hours}小时前`
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <div className="container mx-auto px-4 py-6 max-w-7xl">
        {/* 标题栏 */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6 gap-4">
          <div>
            <h1 className="text-3xl font-bold text-slate-800">LOF基金折溢价计算器</h1>
            <p className="text-slate-600 mt-1">实时估算 · 历史数据 · 估值误差分析 · TickFlow数据源</p>
          </div>
          
          {/* 刷新按钮 */}
          <div className="flex items-center gap-3">
            {/* 缓存状态 */}
            <div className="text-xs text-slate-500 text-right hidden sm:block">
              {lastUpdateTime && (
                <div>更新: {formatTime(lastUpdateTime)}</div>
              )}
              {cacheStats.count > 0 && (
                <div className="text-slate-400">缓存: {cacheStats.count}条</div>
              )}
            </div>
            
            {/* 强制刷新选项 */}
            <label className="flex items-center gap-1 text-sm text-slate-600 cursor-pointer" title="强制刷新会跳过缓存，获取最新的实时行情">
              <input
                type="checkbox"
                checked={forceRefresh}
                onChange={(e) => setForceRefresh(e.target.checked)}
                className="w-4 h-4 rounded"
              />
              强制刷新
            </label>
            
            <button
              className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed font-medium shadow-md"
              onClick={() => fetchBatchData(forceRefresh)}
              disabled={loading || selectedCodes.length === 0}
            >
              {loading ? (
                <span className="flex items-center gap-2">
                  <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                  </svg>
                  获取中...
                </span>
              ) : (
                '🔄 刷新数据'
              )}
            </button>
            
            {/* 清除缓存 */}
            {cacheStats.count > 0 && (
              <button
                onClick={clearAllCache}
                className="px-3 py-2 text-sm text-slate-600 hover:text-red-600 border border-slate-300 rounded-lg hover:border-red-300"
                title="清除所有缓存数据"
              >
                🗑️ 清缓存
              </button>
            )}
          </div>
        </div>

        {/* 添加LOF代码 */}
        <div className="bg-white rounded-lg border border-slate-200 shadow-sm p-4 mb-6">
          <div className="flex flex-col gap-3">
            <textarea
              placeholder="输入基金代码，支持批量添加：&#10;• 多个代码用换行分隔&#10;• 或用中英文逗号(，/)分隔&#10;• 例如：161725,161118 或每行一个代码"
              className="flex-1 px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 min-h-[80px] resize-y"
              onKeyDown={(e) => {
                if (e.key === 'Enter' && e.ctrlKey) {
                  // Ctrl+Enter 快速添加
                  const textarea = e.target as HTMLTextAreaElement
                  addCodes(textarea.value)
                  textarea.value = ''
                }
              }}
            />
            <div className="flex items-center gap-3">
              <button
                onClick={() => {
                  const textarea = document.querySelector('textarea') as HTMLTextAreaElement
                  const result = addCodes(textarea.value)
                  if (result.added > 0 || result.invalid === 0) {
                    textarea.value = ''
                  }
                }}
                className="px-6 py-2 bg-slate-800 text-white rounded-lg hover:bg-slate-700"
              >
                批量添加
              </button>
              <span className="text-xs text-slate-400">提示：Ctrl+Enter 快速添加</span>
            </div>
          </div>
          
          {/* 已选择的代码标签 */}
          {selectedCodes.length > 0 && (
            <div className="flex flex-wrap gap-2 mt-3">
              {selectedCodes.map(code => {
                const item = batchData.find(d => d.code === code)
                const hasCustom = !!customConfigs[code]
                return (
                  <span
                    key={code}
                    className={`inline-flex items-center px-3 py-1 rounded-full text-sm ${
                      hasCustom ? 'bg-amber-100 text-amber-800 border border-amber-300' : 'bg-slate-100 text-slate-800'
                    }`}
                  >
                    <span className="font-medium">{code}</span>
                    {item?.name && <span className="ml-1 text-xs opacity-70">({item.name.slice(0, 4)})</span>}
                    {hasCustom && <span className="ml-1 text-xs" title="已自定义配置">⚙️</span>}
                    <button
                      className="ml-2 hover:text-red-500 font-bold"
                      onClick={() => removeCode(code)}
                    >
                      ×
                    </button>
                  </span>
                )
              })}
            </div>
          )}
        </div>

        {/* 错误提示 */}
        {error && (
          <div className="p-4 bg-red-50 border border-red-200 rounded-lg text-red-700 mb-6">
            {error}
          </div>
        )}

        {/* 实时数据表格 */}
        {batchData.length > 0 && (
          <div className="bg-white rounded-lg border border-slate-200 shadow-sm mb-6">
            <div className="p-4 border-b border-slate-200">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-lg font-semibold text-slate-800">实时折溢价一览</h2>
                  <p className="text-sm text-slate-500 mt-1">
                    点击行展开查看历史数据，勾选"强制刷新"跳过缓存
                  </p>
                </div>
                {lastUpdateTime && (
                  <div className="text-sm text-slate-500 bg-slate-100 px-3 py-1 rounded-full">
                    📅 {formatTime(lastUpdateTime)} 更新
                  </div>
                )}
              </div>
            </div>
            
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200">
                    <th className="px-3 py-3 text-left font-medium">代码</th>
                    <th className="px-3 py-3 text-left font-medium">名称</th>
                    <th className="px-3 py-3 text-right font-medium">前日净值</th>
                    <th className="px-3 py-3 text-right font-medium">今日净值</th>
                    <th className="px-3 py-3 text-right font-medium">现价</th>
                    <th className="px-3 py-3 text-right font-medium">涨跌幅</th>
                    <th className="px-3 py-3 text-right font-medium">指数涨跌</th>
                    <th className="px-3 py-3 text-right font-medium">估算净值</th>
                    <th className="px-3 py-3 text-right font-medium">估算溢价</th>
                    <th className="px-3 py-3 text-right font-medium">估值误差</th>
                    <th className="px-3 py-3 text-center font-medium">操作</th>
                  </tr>
                </thead>
                <tbody>
                  {batchData.map((item) => (
                    <Fragment key={item.code}>
                      <tr
                        className={`border-b border-slate-100 cursor-pointer hover:bg-slate-50 ${
                          expandedCode === item.code ? 'bg-blue-50' : ''
                        } ${item.error ? 'bg-red-50' : ''}`}
                        onClick={() => setExpandedCode(expandedCode === item.code ? null : item.code)}
                      >
                        <td className="px-3 py-3 font-medium">
                          <div className="flex items-center gap-1">
                            {item.code}
                            {item._cachedAt && (
                              <span className="text-xs text-blue-500" title={`缓存于 ${getCacheAge(item._cachedAt)}`}>
                                💾
                              </span>
                            )}
                          </div>
                          {item.data_sources && (
                            <div className="text-xs text-slate-400 mt-0.5">
                              来源: {getSourceName(item.data_sources.quote)}/{getSourceName(item.data_sources.nav)}
                            </div>
                          )}
                        </td>
                        <td className="px-3 py-3 max-w-[120px] truncate">
                          {item.error ? (
                            <span className="text-red-500">{item.error}</span>
                          ) : (
                            item.name || '-'
                          )}
                        </td>
                        <td className="px-3 py-3 text-right">
                          {item.prev_nav ? formatNumber(item.prev_nav) : '-'}
                          <div className="text-xs text-slate-400">{item.prev_nav_date || ''}</div>
                        </td>
                        <td className="px-3 py-3 text-right">
                          {item.nav_updated_today && item.today_nav ? (
                            <>
                              <span className="text-green-600">{formatNumber(item.today_nav)}</span>
                              <div className="text-xs text-green-500">{item.today_nav_date}</div>
                            </>
                          ) : (
                            <span className="text-slate-300">-</span>
                          )}
                        </td>
                        <td className="px-3 py-3 text-right font-medium">{item.price ? formatNumber(item.price, 3) : '-'}</td>
                        <td className="px-3 py-3 text-right">
                          {item.change_percent !== null ? (
                            <span className={item.change_percent >= 0 ? 'text-red-600' : 'text-green-600'}>
                              {formatPercent(item.change_percent)}
                            </span>
                          ) : '-'}
                        </td>
                        <td className="px-3 py-3 text-right">
                          {item.indices && item.indices.length > 0 ? (
                            <>
                              {item.indices.map((idx, i) => (
                                <div key={i} className="flex items-center justify-end gap-1">
                                  {idx.change_percent !== null ? (
                                    <span className={idx.change_percent >= 0 ? 'text-red-600' : 'text-green-600'}>
                                      {formatPercent(idx.change_percent)}
                                    </span>
                                  ) : '-'}
                                  <span className="text-xs text-slate-400">({idx.index_name}×{idx.coefficient})</span>
                                </div>
                              ))}
                              {item.indices.length > 1 && item.total_index_change !== null && (
                                <div className="text-xs text-blue-600 mt-1">
                                  综合: {formatPercent(item.total_index_change)}
                                </div>
                              )}
                            </>
                          ) : '-'}
                        </td>
                        <td className="px-3 py-3 text-right text-blue-600 font-medium">
                          {item.estimated_nav ? formatNumber(item.estimated_nav) : '-'}
                        </td>
                        <td className="px-3 py-3 text-right">
                          {item.premium !== null ? (
                            <span className={`font-bold ${item.premium >= 0 ? 'text-red-600' : 'text-green-600'}`}>
                              {formatPercent(item.premium)}
                            </span>
                          ) : '-'}
                        </td>
                        <td className="px-3 py-3 text-right">
                          {item.estimation_error !== null ? (
                            <span className={`font-medium ${Math.abs(item.estimation_error) > 1 ? 'text-orange-600' : 'text-slate-600'}`}>
                              {formatPercent(item.estimation_error)}
                            </span>
                          ) : '-'}
                          {item.nav_updated_today && (
                            <div className="text-xs text-green-600">已更新</div>
                          )}
                        </td>
                        <td className="px-3 py-3 text-center">
                          <button
                            className="text-blue-600 hover:text-blue-800 text-sm"
                            onClick={(e) => {
                              e.stopPropagation()
                              setEditModal({
                                code: item.code,
                                config: customConfigs[item.code] || {
                                  indices: item.indices?.map(idx => ({
                                    index_code: idx.index_code,
                                    index_name: idx.index_name,
                                    coefficient: idx.coefficient
                                  })) || [{ index_code: '', index_name: '', coefficient: 0.95 }]
                                }
                              })
                            }}
                          >
                            修改
                          </button>
                        </td>
                      </tr>
                      
                      {/* 历史数据展开行 */}
                      {expandedCode === item.code && historyData[item.code] && !item.error && (
                        <tr>
                          <td colSpan={11} className="px-4 py-4 bg-slate-50">
                            <div className="flex items-center justify-between mb-2">
                              <div className="text-sm font-medium text-slate-700">
                                📊 近30日历史数据
                                {historyData[item.code].data_sources && (
                                  <span className="text-xs text-slate-400 ml-2">
                                    来源: {getSourceName(historyData[item.code].data_sources.nav)}/{getSourceName(historyData[item.code].data_sources.kline || '')}
                                  </span>
                                )}
                              </div>
                              {historyData[item.code]._cachedAt && (
                                <span className="text-xs text-blue-500">
                                  💾 缓存于 {getCacheAge(historyData[item.code]._cachedAt)}
                                </span>
                              )}
                            </div>
                            <div className="overflow-x-auto max-h-60 overflow-y-auto">
                              <table className="w-full text-xs">
                                <thead className="sticky top-0 bg-slate-100">
                                  <tr>
                                    <th className="px-2 py-1 text-left">日期</th>
                                    <th className="px-2 py-1 text-right">净值</th>
                                    <th className="px-2 py-1 text-right">收盘价</th>
                                    <th className="px-2 py-1 text-right">折溢价</th>
                                    <th className="px-2 py-1 text-right">指数涨跌</th>
                                    <th className="px-2 py-1 text-right">估算净值</th>
                                    <th className="px-2 py-1 text-right">估算误差</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {historyData[item.code].history?.map((h) => (
                                    <tr key={h.date} className="border-b border-slate-100">
                                      <td className="px-2 py-1">{h.date}</td>
                                      <td className="px-2 py-1 text-right">{h.nav ? formatNumber(h.nav) : '-'}</td>
                                      <td className="px-2 py-1 text-right">{h.price ? formatNumber(h.price, 3) : '-'}</td>
                                      <td className="px-2 py-1 text-right">
                                        {h.premium !== null ? (
                                          <span className={h.premium >= 0 ? 'text-red-600' : 'text-green-600'}>
                                            {formatPercent(h.premium)}
                                          </span>
                                        ) : '-'}
                                      </td>
                                      <td className="px-2 py-1 text-right">
                                        {h.index_change !== null ? (
                                          <span className={h.index_change >= 0 ? 'text-red-600' : 'text-green-600'}>
                                            {formatPercent(h.index_change)}
                                          </span>
                                        ) : '-'}
                                      </td>
                                      <td className="px-2 py-1 text-right text-blue-600">
                                        {h.estimated_nav ? formatNumber(h.estimated_nav) : '-'}
                                      </td>
                                      <td className="px-2 py-1 text-right">
                                        {h.estimation_error !== null ? (
                                          <span className={Math.abs(h.estimation_error) > 1 ? 'text-orange-600' : 'text-slate-600'}>
                                            {formatPercent(h.estimation_error)}
                                          </span>
                                        ) : '-'}
                                      </td>
                                    </tr>
                                  ))}
                                </tbody>
                              </table>
                            </div>
                          </td>
                        </tr>
                      )}
                    </Fragment>
                  ))}
                </tbody>
              </table>
            </div>
            
            {/* 计算说明 */}
            <div className="p-3 bg-blue-50 border-t border-slate-200">
              <div className="text-sm text-blue-700">
                <strong>计算说明：</strong>
                <span className="mx-2">|</span>
                估算净值 = 前日净值 × (1 + Σ(指数涨跌幅 × 校正系数))
                <span className="mx-2">|</span>
                估算溢价 = (现价 - 估算净值) / 估算净值 × 100%
                <span className="mx-2">|</span>
                估值误差 = (实际净值 - 估算净值) / 估算净值 × 100%（今日净值更新后显示）
              </div>
            </div>
          </div>
        )}

        {/* 无数据提示 */}
        {batchData.length === 0 && !loading && (
          <div className="text-center py-12 text-slate-500 bg-white rounded-lg border border-slate-200">
            <p className="text-lg">请在上方添加LOF基金代码后点击"刷新数据"</p>
            <p className="text-sm mt-2">LOF代码以16或50开头，数据将自动保存</p>
          </div>
        )}

        {/* 修改配置弹窗 */}
        {editModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-6 w-full max-w-lg mx-4 max-h-[90vh] overflow-y-auto">
              <h3 className="text-lg font-semibold mb-4">修改指数配置 - {editModal.code}</h3>
              
              <div className="space-y-4">
                <div className="text-sm text-slate-500 mb-2">
                  支持配置最多3个追踪指数，估算净值 = 前日净值 × (1 + Σ(指数涨跌幅 × 系数))
                </div>
                
                {editModal.config.indices.map((idx, i) => (
                  <div key={i} className="p-3 bg-slate-50 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium text-sm">指数 {i + 1}</span>
                      {editModal.config.indices.length > 1 && (
                        <button
                          className="text-red-500 text-xs hover:text-red-700"
                          onClick={() => {
                            const newIndices = editModal.config.indices.filter((_, idx) => idx !== i)
                            setEditModal({
                              ...editModal,
                              config: { ...editModal.config, indices: newIndices }
                            })
                          }}
                        >
                          删除
                        </button>
                      )}
                    </div>
                    <div className="grid grid-cols-3 gap-2">
                      <div>
                        <label className="block text-xs text-slate-500 mb-1">指数代码</label>
                        <input
                          type="text"
                          value={idx.index_code}
                          onChange={(e) => {
                            const newIndices = [...editModal.config.indices]
                            newIndices[i] = { ...newIndices[i], index_code: e.target.value }
                            setEditModal({
                              ...editModal,
                              config: { ...editModal.config, indices: newIndices }
                            })
                          }}
                          placeholder="如：399997"
                          className="w-full px-2 py-1 border border-slate-300 rounded text-sm focus:outline-none focus:ring-1 focus:ring-blue-500"
                        />
                      </div>
                      <div>
                        <label className="block text-xs text-slate-500 mb-1">指数名称</label>
                        <input
                          type="text"
                          value={idx.index_name}
                          onChange={(e) => {
                            const newIndices = [...editModal.config.indices]
                            newIndices[i] = { ...newIndices[i], index_name: e.target.value }
                            setEditModal({
                              ...editModal,
                              config: { ...editModal.config, indices: newIndices }
                            })
                          }}
                          placeholder="如：中证白酒"
                          className="w-full px-2 py-1 border border-slate-300 rounded text-sm focus:outline-none focus:ring-1 focus:ring-blue-500"
                        />
                      </div>
                      <div>
                        <label className="block text-xs text-slate-500 mb-1">校正系数</label>
                        <input
                          type="number"
                          step="0.01"
                          value={idx.coefficient}
                          onChange={(e) => {
                            const newIndices = [...editModal.config.indices]
                            newIndices[i] = { ...newIndices[i], coefficient: parseFloat(e.target.value) || 0.95 }
                            setEditModal({
                              ...editModal,
                              config: { ...editModal.config, indices: newIndices }
                            })
                          }}
                          className="w-full px-2 py-1 border border-slate-300 rounded text-sm focus:outline-none focus:ring-1 focus:ring-blue-500"
                        />
                      </div>
                    </div>
                  </div>
                ))}
                
                {editModal.config.indices.length < 3 && (
                  <button
                    className="w-full py-2 border-2 border-dashed border-slate-300 rounded-lg text-slate-500 hover:border-blue-400 hover:text-blue-500 text-sm"
                    onClick={() => {
                      setEditModal({
                        ...editModal,
                        config: {
                          ...editModal.config,
                          indices: [...editModal.config.indices, { index_code: '', index_name: '', coefficient: 0.95 }]
                        }
                      })
                    }}
                  >
                    + 添加指数
                  </button>
                )}
                
                <div className="text-xs text-slate-400 mt-2">
                  常用指数代码：399997(中证白酒)、000932(中证消费)、399989(中证医疗)、
                  399967(中证军工)、000300(沪深300)、000905(中证500)、399006(创业板指)
                </div>
              </div>
              
              <div className="flex gap-3 mt-6">
                <button
                  onClick={() => setEditModal(null)}
                  className="flex-1 px-4 py-2 border border-slate-300 rounded-lg hover:bg-slate-50"
                >
                  取消
                </button>
                <button
                  onClick={() => updateCustomConfig(editModal.code, editModal.config)}
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  保存
                </button>
              </div>
            </div>
          </div>
        )}

        {/* 页脚 */}
        <footer className="mt-8 text-center text-sm text-slate-500">
          <p>数据来源：TickFlow API（指数行情、K线）+ 东财API（LOF净值）| 仅供参考，不构成投资建议</p>
        </footer>
      </div>
    </div>
  )
}
